module shapes {
	requires java.desktop;
}