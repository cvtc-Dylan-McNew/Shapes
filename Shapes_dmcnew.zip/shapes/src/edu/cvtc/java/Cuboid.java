/**
 * 
 */
package edu.cvtc.java;

import javax.swing.JOptionPane;

/**
 * @author 17178
 *
 */
public class Cuboid extends Shape {
	// variables
	private float width;
	private float height;
	private float depth;
	
	//getters and setters
	public float getWidth() {
		return width;
	}
	public void setWidth(float width) {
		this.width = width;
	}
	
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	
	public float getDepth() {
		return depth;
	}
	public void setDepth(float depth) {
		this.depth = depth;
	}
	
	//Constructor
	public Cuboid(float width, float height, float depth) {
		
		this.width = width;
		this.height = height;
		this.depth = depth;
	}
	
	
	@Override
	public float surfaceArea() {
		// return the equation for surface area using an abstract method
		return (2 * depth * width) + (2 * depth * height) + (2 * height * width);
	}
	@Override
	public float volume() {
		// return the equation for volume using an abstract method
		return depth * width * height;
	}
	@Override
	public void render() {
		// render method to display output in a pop up box
		JOptionPane.showMessageDialog(null, 
		"the dimensions of this cuboid are \n"
		+ "width: " + width + "\n"
		+ "depth: " + depth + "\n"
		+ "height: " + height + "\n"
		+ "With a volume of: " + volume() + "\n"
		+ "and a surface area of: " + surfaceArea(),
		"A plain message",
		JOptionPane.PLAIN_MESSAGE);
	}
	
	

}
