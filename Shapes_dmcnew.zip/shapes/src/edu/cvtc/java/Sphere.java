/**
 * 
 */
package edu.cvtc.java;

import javax.swing.JOptionPane;

/**
 * @author 17178
 *
 */
public class Sphere extends Shape {
	//Variables.
	private float radius;

	//Getters and setters.
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	//Constructor
	public Sphere(float radius) {
	
		this.radius = radius;
	}

	@Override
	public float surfaceArea() {
		// return the equation for surface area using an abstract method
		return (float) (4 * Math.PI * Math.pow(radius, 2));
	}

	@Override
	public float volume() {
		// return the equation for volume using an abstract method
		return (float) (4.0 / 3 * Math.PI * Math.pow(radius, 3));
	}

	@Override
	public void render() {
		// render method to display output in a pop up box
		JOptionPane.showMessageDialog(null, 
		"the dimensions of this sphere are\n"
		+ "radius: " + radius + "\n"
		+ "With a volume of: " + volume() + "\n"
		+ "and a surface area of: " + surfaceArea(),
		"A plain message",
		JOptionPane.PLAIN_MESSAGE);
	}
	
	
	
}
