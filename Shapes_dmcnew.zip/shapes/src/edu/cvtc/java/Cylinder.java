/**
 * 
 */
package edu.cvtc.java;

import javax.swing.JOptionPane;

/**
 * @author 17178
 *
 */
public class Cylinder extends Shape {
	//variables
	private float radius;
	private float height;
	
	//getters and setters
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}
	
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	
	// constuctor
	public Cylinder(float radius, float height) {
		
		this.radius = radius;
		this.height = height;
	}
	@Override
	public float surfaceArea() { 		
	// return the equation for surface area using an abstract method
		return  (float) ((2 * Math.PI * radius * height) + (2 * Math.PI * Math.pow(radius, 2)));
	}
	@Override
	public float volume() {
		// return the equation for volume using an abstract method
		return (float) (Math.PI * Math.pow(radius, 2) * height);
	}
	@Override
	public void render() {
		// render method to display output in a pop up box
		JOptionPane.showMessageDialog(null, 
		"the dimensions of this cylinder are\n"
		+ "radius: " + radius + "\n"
		+ "height: " + height + "\n"
		+ "With a volume of: " + volume() + "\n"
		+ "and a surface area of: " + surfaceArea(),
		"A plain message",
		JOptionPane.PLAIN_MESSAGE);
	}
	
	

}
