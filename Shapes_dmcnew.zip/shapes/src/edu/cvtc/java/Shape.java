/**
 * 
 */
package edu.cvtc.java;

/**
 * @author 17178
 *
 */
public abstract class Shape {
	//Abstract methods for each class.
	public abstract float surfaceArea(); 
		
	public abstract float volume();
	
	public abstract void render();


	
}
