/**
 * 
 */
package edu.cvtc.java;

/**
 * @author 17178
 *
 */
public class ShapesTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Making instances of my shape objects.
		Cuboid newCuboid = new Cuboid(5, 3, 8);
		
		Cylinder newCylinder = new Cylinder(5, 9);
		
		Sphere newSphere = new Sphere(7);
		
		//Calling the render abstract methods for each new object.
		newCuboid.render();
		newCylinder.render();
		newSphere.render();
	}

}
